<?php
/**
 * The template for displaying the footer
 *
 * @package TW_Assivo
 * @since TW_Assivo 1.0
 */
 
if (!is_page_template( 'get-started.php')){ ?> 
	<footer>
		<div class="container mt-5">
			<div class="row mb-2 mx-auto">
			        <div class="col-lg-3 col-sm-7 footer-section pb-lg-1 pb-4 px-md-0 px-2">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo-blue.png"></a>
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer Content") ) : ?>
					<?php endif;?>
				</div>
				
				<div class="col-lg-3 col-sm-5 pt-lg-4 pt-3 pl-lg-5 pb-sm-5 pb-lg-1  px-2">
					<h5>COMPANY</h5>
					<?php wp_nav_menu( array( 'theme_location' => 'secondary' ) ); ?>
				</div>
				<div class="col-lg-3 col-sm-7 pt-lg-4 pt-3 pl-xl-4 px-md-0 pb-lg-1 px-2">
					<h5>OUR SERVICES</h5>
					<?php wp_nav_menu( array( 'theme_location' => 'services_Menu' ) ); ?>
				</div>
				<div class="col-lg-3 contact-us-footer col-sm-5 pt-lg-4 pt-3 pl-xl-4 px-md-0 px-sm-0 px-2 py-3">
					<div class="get-footer">
						<a class="assivo-contact-us text-center text-white border-0 font-weight-bold" href="<?php echo get_permalink('334');?>">Request A Proposal</a>
					</div>
				</div>
				
			</div>
			<div class="row copyrights pt-2">
				<div class="col-sm-3 col-12 copyrights-date px-0">
					<p>&copy; <?php echo date("Y"); ?> Assivo, Inc. </p>
				</div>
				<div class="col-sm-9 col-12 p-0 m-0 pr-xl-1 copyrights-terms">
					<p>All Rights Reserved &nbsp;&nbsp;|&nbsp;&nbsp;
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>information-and-data-security">Information &amp; Data Security</a>&nbsp;&nbsp; |&nbsp;&nbsp;
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>privacy-policy">Privacy Policy </a>&nbsp;&nbsp; |&nbsp;&nbsp;
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>terms-conditions">Terms &amp; Conditions</a>
					
					</p>
				</div>
			</div>
		</div>
	</footer>
<?php } 
if (is_page_template( 'get-started.php')){ ?> 
	<script>
		var url_string = window.location.href;
		var url = new URL(url_string);
		var email = url.searchParams.get("email");
		document.getElementById('email_custom').value = email;
	</script>
<?php }
else { ?>
	<script>
		var url_string = window.location.href;
		var url = new URL(url_string);
		var email = url.searchParams.get("email");
		document.getElementById('email').value = email;
		if (typeof email!= 'undefined' && email) {
			document.getElementById('request_proposal').scrollIntoView(true);
		}
	</script>
<?php } ?>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/jquery.min.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/bootstrap.min.js"></script>
	<script>
		$(document).ready(function(){
		    
	   $(".toggle-i-circle").click(function () {
                    $(".toggle-i-circle").each(function(){
				if($(this).attr('aria-expanded')=='true'){
				   $(this).removeClass("i-minus").addClass("i-plus");	
				}
			});
                    if ($(this).hasClass("collapsed")) {
                        $(this).toggleClass("i-minus i-plus");
                    }
        });
          $(".toggle-circle").click(function () {
            $(".toggle-circle").each(function(){
						if($(this).attr('aria-expanded')=='true'){
						   $(this).removeClass("minus").addClass("plus");	
						}
					});
            if ($(this).hasClass("collapsed")) {
            $(this).toggleClass("minus plus");
            }

        });
                $("body").click(function (e) {
                     
                    if($(e.target).is('.link')){
						$(".toggle-i-circle").each(function(){
						if($(this).attr('aria-expanded')=='true'){
						   $(this).removeClass("i-minus").addClass("i-plus");	
						}
					});
                    $(e.target).parent().find('a').addClass("i-plus").removeClass("i-minus");
                    if ($(e.target).parent().find('a').hasClass("collapsed")) {
                        $(e.target).parent().find('a').toggleClass("i-minus i-plus");
                      }
						
                    }
					if($(e.target).is('.faq-head')){
						$(".toggle-circle").each(function(){
						if($(this).attr('aria-expanded')=='true'){
						   $(this).removeClass("minus").addClass("plus");	
						}
					});
                    $(e.target).parent().find('a').addClass("plus").removeClass("minus");
                    if ($(e.target).parent().find('a').hasClass("collapsed")) {
                        $(e.target).parent().find('a').toggleClass("minus plus");
                      }
					}
					
                });
// 			    $('.filter-check').prop('checked', true);
            $("#search-case").on("keyup", function () {
                $('.case-box').hide();
                $('.study_box').hide();
                $('.case-box').removeClass('searchresults');
                $('.study_box').removeClass('searchresults');
                var value = $(this).val().toLowerCase();
                if (value == "") {
//                     $('.filter-check').trigger('click');
                    $('.case-box').hide();
					$('.study_box').hide();

					if (pagename == 'usecase') {
						create_pages('case-box', '');
					}
					if (pagename == 'casestudy') {
						create_pages('study_box', '');
					}                     
                    return false;
                }

                $(".case-box").filter(function () {
//                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
//                    $("#case-title").text('All Cases');
                    if ($(this).text().toLowerCase().indexOf(value) > -1) {
                        $(this).addClass('searchresults');
                    }
                });
                $(".study_box").filter(function () {
//                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
//                    $("#case-title").text('All Studies');
                    if ($(this).text().toLowerCase().indexOf(value) > -1) {
                        $(this).addClass('searchresults');
                    }
                });


                create_pages('searchresults', 'searched');






            });

            function create_pages(newclass, newid) {



                var count = 0;
                var pagelist = '<ul class="pagination">';
                $('.' + newclass).each(function () {
                    count++;

                });
                var pageselect = count / totalcontents;
				if (Number.isInteger(pageselect)==false) {
// 					alert(Number.isInteger(pageselect));
                    pageselect+=1;
                  }
// 				alert(pageselect);
             
				if(pageselect >=2 ){
		        for (j = 1; j <= pageselect; j++) {
                    acclass = '';
					
					if(pageselect==j){
					  
					   }
                    if (j == 1) {
                        acclass = 'active';
                        pagelist += '<li class="page-item ' + acclass + '"><a class="page-link" href="#" page="1"  id="' + newid + '">First</a></li>';
                    }
                    pagelist += '<li class="page-item ' + acclass + '" ><a class="page-link" href="#" page="' + j + '" id="' + newid + '">' + j + '</a></li>';
                } 
				}
                j -= 1;
                if (pagelist != '<ul class="pagination">') {

                    pagelist += '<li class="page-item " ><a class="page-link" href="#" page="' + j + '" id="' + newid + '">Last</a></li>';
                }
                pagelist += '</ul>';
                $('.pagenation-list').html('');
                $('.pagenation-list').html(pagelist);
                $('.' + newclass).slice(0, totalcontents).show();





            }




            $(".case-filter").click(function (e) {
                e.preventDefault();
                $(this).siblings('.filter-check').trigger('click');
            });

            ///////////Checkbox Filter code
//            $(".filter-check").prop('checked', true);
            $(".filter-check").click(function () {
                $(".case-box").removeClass('selected-cat');
                $(".study_box").removeClass('selected-cat');
                $("#case-title").text("");
//                                $(".all-filter-check").prop('checked',false);
                var selected = [];
                $('body').find('.filter-check').each(function () {

                    if ($(this).prop("checked") == true) {

                        var text = $(this).siblings('.case-filter').find('span').text();
                        var type = $(this).siblings('.case-filter').data('type');
                        var list = $(this).siblings('.case-filter').data(type);
                        if (list == '') {
                            list = type;
                        }
                        selected.push(list);

                    }

                });

                $(".case-box").hide();
                $(".study_box").hide();
                $(".category").hide();
                if (selected.length === 0) {
//                     $('.all-cat').trigger('click');
//                     $('.all-verticals').trigger('click');
                    $('.case-box').hide();
					$('.study_box').hide();

					if (pagename == 'usecase') {
						create_pages('case-box', '');
					}
					if (pagename == 'casestudy') {
						create_pages('study_box', '');
					}
					
					
                }
				if(selected.length != 0){
				    $.each(selected, function (i, v) {

                    $(".case-box").each(function () {

                        if ($(this).hasClass(v)) {

                            $(this).addClass('selected-cat');
                        }
                    });
                    $(".category").each(function () {
                        if ($(this).hasClass(v)) {
                            $(this).addClass('selected-cat');
                        }
                    });
                    $(".study_box").each(function () {
                        if ($(this).hasClass(v)) {
                            $(this).addClass('selected-cat');
                        }
                    });
                });
                   create_pages('selected-cat', 'selected');
				}
               
                
            });
            $('body').click(function (e) {
// 				alert($(e.target).attr('class'));
                if ($(e.target).is('#selected')) {
                    e.preventDefault();
                    $('.case-box').hide();
                    $('.study_box').hide();
                    $('.page-item').removeClass('active');
                    $(e.target).parent('.page-item').addClass('active');
//                               alert($(this).find('.page-link').html());
                    selpage = $(e.target).attr('page');
					select_pages(selpage);
                    next = selpage * totalcontents;
                    offset = next - totalcontents;
                    $(".selected-cat").slice(offset, next).show();
                }
                if ($(e.target).is('#searched')) {
                    e.preventDefault();
                    $('.case-box').hide();
                    $('.study_box').hide();
                    $('.page-item').removeClass('active');
                    $(e.target).parent('.page-item').addClass('active');
//                               alert($(this).find('.page-link').html());
                    selpage = $(e.target).attr('page');
					select_pages(selpage);
                    next = selpage * totalcontents;
                    offset = next - totalcontents;
                    $(".searchresults").slice(offset, next).show();
                }
                if ($(e.target).is('.page-link')) {
                    e.preventDefault();
					if($(e.target).attr('id')==''){
                            $('.case-box').hide();
							$('.study_box').hide();
							$('.page-item').removeClass('active');
							$(e.target).parent('.page-item').addClass('active');
		//                               alert($(this).find('.page-link').html());
							selpage = $(e.target).attr('page');
						    select_pages(selpage);
							next = selpage * totalcontents;
							offset = next - totalcontents;
							$(".case-box").slice(offset, next).show();
						    $(".study_box").slice(offset, next).show();
					   }
                  
                }


            });
            $('.all-cat').click(function () {
                $('.filter-check').each(function () {
                    if ($(this).attr('name') == 'category') {
                        $(this).prop('checked', true);
                    }
                });
                $('input[name="category"]').first().trigger('click');
                $('input[name="category"]').first().trigger('click');
                return false;
            });
            $('.all-verticals').click(function () {
                $('.filter-check').each(function () {
                    if ($(this).attr('name') == 'verticles') {
                        $(this).prop('checked', true);
                    }
                });
                $('input[name="verticles"]').first().trigger('click');
                $('input[name="verticles"]').first().trigger('click');
                return false;
            });


            //----------------paggination-----------------
            $('.case-box').hide();
            $('.study_box').hide();

            if (pagename == 'usecase') {
                create_pages('case-box', '');
            }
            if (pagename == 'casestudy') {
                create_pages('study_box', '');
            }




            $(".page-item").on('click', function (e) {
                e.preventDefault();
                $('.case-box').hide();
                $('.study_box').hide();
                $('.page-item').removeClass('active');
                $(this).addClass('active');
				
//                               alert($(this).find('.page-link').html());
                selpage = $(this).find('.page-link').attr('page');
			    
				select_pages(selpage);
				next = selpage * totalcontents;
                offset = next - totalcontents;
                $('.case-box').slice(offset, next).show();
                $('.study_box').slice(offset, next).show();
				
				
            });

             function select_pages(selpage){
				 lastval=$('.page-item').last().find('.page-link').attr('page');
				 if(selpage==1){
				   $('.page-item').slice(0,2).find('.page-link').css('background-color','#007bff');
					$('.page-item').slice(0,2).find('.page-link').css('color','#fff');
				    $('.page-item').slice(-2).find('.page-link').css('background-color','#fff');
					$('.page-item').slice(-2).find('.page-link').css('color','#007bff');    
				}
				else if(selpage==lastval){
		         	$('.page-item').slice(-2).find('.page-link').css('background-color','#007bff');
					$('.page-item').slice(-2).find('.page-link').css('color','#fff');  
					$('.page-item').slice(0,2).find('.page-link').css('background-color','#fff');
					$('.page-item').slice(0,2).find('.page-link').css('color','#007bff');
				   }
				else{
					$('.page-item').slice(0,2).find('.page-link').css('background-color','#fff');
					$('.page-item').slice(0,2).find('.page-link').css('color','#007bff');
					$('.page-item').slice(-2).find('.page-link').css('background-color','#fff');
					$('.page-item').slice(-2).find('.page-link').css('color','#007bff'); 
				}
			 }
			
			  	
			
		});
		
// 		$(document).ready(function(){
// 			$('.flip-box-front h5').on('click',function(){
// 				// alert('hello');
// 				$(this).closest('.flip-box-front').trigger('click');
// 			});
// 		});
		

	</script>
	<script>
		var base_url='<?php echo esc_url( get_template_directory_uri() )?>';
	</script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/smooth_scroll.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/custom.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/slider_owl.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/owlcarousel/owl.carousel.min.js"></script>
	<?php wp_footer(); ?>
</body>
</html>
