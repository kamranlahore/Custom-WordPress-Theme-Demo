<?php
/**
 * 
 *
 * @package TW_Assivo
 * @since TW_Assivo 1.0
 */
get_header(); 

 ?>

	<section class="use-case">
		<div class="container">
			<div class="row no-gutters">
				<?php
					$i=1;
					$args = array( 'post_type' => 'case_studies', 'posts_per_page' => 6 );
					$loop = new WP_Query( $args );
					while ( $loop->have_posts() ) : $loop->the_post();
					$post_id = get_the_ID();
					$taxonomies=get_taxonomies('','names');
					$taxo=wp_get_post_terms($post_id, $taxonomies,  array("fields" => "slugs"));
					$length = count($taxo);
				?>
				<div class="col-md-12 det_study pb-2 <?php if($i==1){echo "mt-2";}else{echo "mt-5";}?>">
					<div class="header_study">
						<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/aaadata.png" alt=""/>
						<h2><?php echo wp_trim_words( the_title(),3, '...' );?></h2>
					</div>
					<div class="content_study">
						<?php
							$company_stage = get_field('company_stage');
							if( $company_stage): ?>
							<span>Client:
								<?php foreach( $company_stage as $company_stage ): ?>
									<?php echo $company_stage; ?>
								<?php endforeach; ?>
							</span>
							<?php endif; ?>
						<!--<span>Client: Series B Healthcare Company </span>-->
						<?php echo '<p>'.wp_trim_words( get_the_excerpt(),30, '...' ).'</p>';?>
						<div class="row mx-auto px-2">
							<div class="col-md-4 contnt_div">
								<div class="study_boxes pb-2">
									<h3>Problem</h3>
									<p><?php $problem_challanges = get_field('problem__challenge');
									echo wp_trim_words($problem_challanges,60, '...' ); ?></p>
								</div>
								<a href="<?php echo get_permalink();?>">LEARN MORE</a>
							</div>
							<div class="col-md-4 contnt_div">
								<div class="study_boxes pb-2">
									<h3>
									<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/aaaassivo-black-logo.png" alt=""/>
									<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/aaassivo-blue-logo.png" alt=""/>assivo Solutions</h3>
									<p>
										<?php $assivo_solution = get_field('assivo_solution');
										echo wp_trim_words($assivo_solution,60, '...' ); ?></p>
									</p>
								</div>
								<a href="<?php echo get_permalink();?>">LEARN MORE</a>
							</div>
							<div class="col-md-4 contnt_div">
								<div class="study_boxes pb-2">
									<h3>Results</h3>
									<p>
										<?php $problem_challanges = get_field('problem__challenge');
										echo wp_trim_words($problem_challanges,60, '...' ); ?></p>
									</p>
								</div>
								<a href="<?php echo get_permalink();?>">LEARN MORE</a>
							</div>
						</div>
					</div>
				</div>
				<?php
					$i++;
					endwhile;
				?>
			</div>
		</div>
	</section>

	<?php get_template_part( 'template-parts/how_it_works', 'none' );?>
	
<?php get_footer();