<?php
/**
 * 
 *
 * @package TW_Assivo
 * @since TW_Assivo 1.0
 */

get_header(); ?>

	<section class="use-case usecase_detail pb-3">
		<div class="container">
			<div class="row no-gutters text-center">
				<div class="col-12 mt-1 mb-3 department">
					<div class="row">
						<div class="col-md-2 my-2">							
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/general inquries.png" alt="" />
							<h4>Press & General Inquiries</h4>
							<a href="mailto:hello@assivo.com">hello@assivo.com</a>
						</div>
						<div class="col-md-2 my-2">							
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/sales-business-development.png" alt="" />
							<h4>Sales & Business Development</h4>
							<a href="mailto:sales@assivo.com">sales@assivo.com</a>
						</div>
						<div class="col-md-2 my-2">						
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/finance.png" alt="" />
							<h4>Accounting & Finance</h4>
							<a href="mailto:finance@assivo.com">finance@assivo.com</a>
						</div>
						<div class="col-md-2 my-2">
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/customer-services.png" alt="" />
							<h4>Customer Success</h4>
							<a href="mailto:careers@assivo.com">success@assivo.com</a>
						</div>
						<div class="col-md-2 my-2">
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/careers.png" alt="" />
							<h4>Careers</h4>
							<a href="" >careers@assivo.com</a>
						</div>
					</div>
				</div>
				<div class="col-md-10 mx-auto get-touch-form contact_form text-center mt-1">
					<div class="row m-0">
						<div class="col-lg-7 col-md-6 pt-4 text-sm-left explore-contact px-0">
							<h3>CONTACT FORM</h3>
						</div>
						<div class="col-lg-5 col-md-6 pt-md-2 contact_phone pr-0 m-sm-0 text-md-right">
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/conatct_phone.png" alt="" />
							<h4>(888) 998-2754</h4>
						</div>
						<div class="get-started-form-box"> 
							<?php echo do_shortcode( '[contact-form-7 id="112" title="Contact Us Form"]' ); ?>	
						</div>
					</div>	
				</div>
			</div>
		</div>
	</section>
	<section class="executive_section text-center pt-2 pb-5">
		<div class="container">
			<div class="row"> 
				<div class="col-12 mx-0 my-5 py-4 px-md-0 px-3 executive_officer">
					<div class="row m-0">
						<div class="col-md-9 bg-gradient py-4 px-4 text-left">
							<h3> Executive Offices </h3>
						</div>
						<div class="col-md-3 pt-3 pb-1 pl-lg-3 px-2 text-left india_center desktop_767">
							<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/india_center.png" alt="" />
							<h4>India Operations Centers</h4>
						</div>
					</div>
					<div class="row m-0">
						<div class="col-md-9 p-0 px-3 offices_executive">
							<div class="row">
								<div class="col-sm-6 px-0">
									<div class="row ml-sm-3 mr-sm-3 m-2 my-sm-4 pt-5 p-0 headoffice_Flag">
										<div class="col-12 d-block mt-2 px-lg-5 align-middle text-left">
											<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/head_location.png" alt="" />
											<h4>Chicago</h4>
										</div>	
										<div class="col-12 px-1 pt-2 d-block text-center">
											<p>401 N. Michigan Ave<br>Suite 1200<br>Chicago, IL 60611</p>
										</div>
									</div>
								</div>
								<div class="col-sm-6 px-0">
									<div class="row ml-sm-3 mr-sm-3 m-2 my-sm-4 pt-5 p-0 headoffice_Flag">
										<div  class="col-12 d-block mt-2 px-lg-5 align-middle text-left"> 
											<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/head_location.png" alt="" />
											<h4>Mumbai </h4>
										</div>
										<div  class=" col-12 px-1 pt-2 d-block"> 
											<p>Maker Towers E, 16th Floor<br>Cuffe Parade<br>Mumbai 400005</p>
										</div>
									</div>
								</div>
							</div>
						</div> 
						<div class="col-md-3 indian_offices text-left p-0">
							<div class="pt-3 pb-1 pl-lg-3 px-2 india_center mobile_767">
								<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/india_center.png" alt="" />
								<h4>India Operations Centers</h4>
							</div>
							<ul class="">
								<li>
									<a href="#" class="" data-category="audio-transcription" data-type="category">
										<span>Hyderabad</span>
									</a>
								</li>
								<li>
									<a href="#" class="" data-category="data-mining" data-type="category">
										<span>Chennai</span>
									</a>
								</li>
								<li>
									<a href="#" class="" data-category="content-moderation" data-type="category">
										<span>Mumbai</span>
									</a>
								</li>
								<li>
									<a href="#" class="" data-category="machine-learning" data-type="category">
										<span>Pune</span>
									</a>
								</li>
							</ul>
						</div>
					</div>
					
					
				</div>
			</div>
		</div>
	</section>
	
	<?php get_footer(); ?>