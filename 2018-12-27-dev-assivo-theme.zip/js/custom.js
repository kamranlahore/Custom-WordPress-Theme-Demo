$(document).ready(function() {
    //start here
   	  var height_cal = 0 ;
	  var get_height = 0 ;
	  var remove_height = 0;
	$(".search-menu img").click(function() {
	   $(".search-box").toggle();
	   $(".search-box input[type='text']").focus();
	 });
	
	
	//Auto Main Banner Image Height
	function main_banner_height(selector){
		var background = $(selector).css('background-image');
		//var
		// If the background image is anything other than "none"
			// Find and replace "url()" to get the pure image URL
			/* background = background.replace('url("', '').replace('")', ''); */
				background1 = background.replace('url(', '').replace(')', '');
				if (background1.indexOf('"') != -1) {
				background1 = background.replace('url("', '').replace('")', '');

				}
			// Create new Image instance and set path to our background
			var bg = new Image();
			bg.src = background1;
			// We now have serveral vars availible to pass through to the plugin
			// self = the element
			// background = the url
			// bg.width = image width
			// bg.height = image height


			var orginal_img_width  = bg.width;
			var orginal_img_height = bg.height;
			var req_height_percentage = (orginal_img_height / orginal_img_width ) * 100;

			var wind_widht = $( window ).width();
			var calculate_height =( (wind_widht / 100) * req_height_percentage +1 ) ;
			//console.log('background:' + background);
			
			//console.log("orginal_img_width:"+bg.width+",orginal_img_height:"+bg.height,"req_height_percentage:"+req_height_percentage,"wind_widht:"+wind_widht,"calculate_height:"+calculate_height);

			$(selector).height(calculate_height);
// 		$(selector).css('height',calculate_height+' !important');
	
	return calculate_height;
	}
	
	//Banner Height On Load

	$( window ).on( "load", function() {
			console.log( "window loaded" );
		
			if($('.assive-home-page').length){
			    main_banner_height('.assive-home-page');
			}
			if($('.hybrid-model').length){
			    main_banner_height('.hybrid-model');
			}
		
	
	});
			
	//Banner Height On Ressise window
        $( window ).resize(function() {
		   //Banner Height On Load
			
			if($('.assive-home-page').length){
			   main_banner_height('.assive-home-page');
			}
			if($('.hybrid-model').length){
			   main_banner_height('.hybrid-model');
			}
		});

/**********Scroll to div Function *****************************

  $(".scrollTo").on('click', function(e) {
     e.preventDefault();
     var target = $(this).attr('href');
     $('html, body').animate({
       scrollTop: ($(target).offset().top)
     }, 2000);
  });
	height_cal =  main_banner_height('.assive-home-page');
	get_height = height_cal - 70;
	remove_height = (get_height) - 0.25;
	*/
/*
   $(window).on("scroll", function() {
	
		if (!$("body").hasClass("page-template-get-started")){
			if (!$("body").hasClass("page-template-landing")){
				if($(window).scrollTop() > 0.5) {
					$("header").addClass("nav_g");
				}
				else{
					$("header").removeClass("nav_g");
				}
				if($(window).scrollTop() > 1) {						
					$("header").addClass("nav-bg");
					$("header").addClass("desk_responsive_head");
					$("header.desk_responsive_head").attr("style","background:linear-gradient(to right, #4775e5,#8e53e9) !important;");
				    $(".assivo-banner-text.desktop_view").css("display","none");
				    if ($(window).width() > 865){
				  //      $(".use-case").attr("style","margin-top:15% !important;");
				    }
				    else{
				  //  	$("section.mobile_view:nth-child(3)").attr("style","margin-top:15% !important;");
				    }
					
				} 
				else {
				 $("header.desk_responsive_head").attr("style","background:unet!important;");
				       $("header").removeClass("desk_responsive_head");
				       $("header").addClass("back_responsive");
					   $("header").removeClass("nav_g");
				       $(".nav-position").removeClass("nav-bg");
					    
				       $("header").removeClass("nav-bg");
				       main_banner_height('header');
				       if ($(window).width() > 865){
				     	  	$(".assivo-banner-text.desktop_view").css("display","block"); 
						    $(".assivo-banner-text.desktop_view").slideDown("slow");
				     	  //	$(".use-case").attr("style","margin-top:5% !important;");
				       }
					else{
				       	   //	$("section.mobile_view:nth-child(3)").attr("style","margin-top:5% !important;");
				       	}
				}
			}
	       }
	});  */
});
//-----------------------------search forms-------------------------

$(document).ready(function(){
  $('.wpcf7-form-control-wrap .email').hide();
    $('.placeholder-abst').click(function(){
//       alert('hello');
        $(this).parent().parent().find('.wpcf7-email').focus();
        var myclass='';
        if($(window).width() <= 865){
          myclass='.mobile_view';
        }
        else{
           myclass='.desktop_view';
        }
        $(this).parent().parent().find(myclass).hide();
        
    });
    $('.wpcf7-email').focusout(function(){
        
        if( $(this).val() == ''){
         //alert($(this).val());
         var myclass='';
        if($(window).width() <= 865){
          myclass='.mobile_view';
        }
        else{
           myclass='.desktop_view';
        }
          $(this).parent().parent().find(myclass).show(); 
      }
    });
});
$(document).ready(function(){
    $('.flip-box-front h5').on('click',function(){
//        alert('hello');
       $(this).closest('.flip-box-front').trigger('click');
    });
});