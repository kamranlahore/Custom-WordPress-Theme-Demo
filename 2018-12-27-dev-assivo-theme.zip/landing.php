<?php
/**
 * Template Name: Landing Page
 *
 * @package TW_Assivo
 * @since TW_Assivo 1.0
 */

get_header('landing');  
   	 global $post;
    	$post_slug=$post->post_name;
	$file_name = explode('-', $post_slug, 2);
	$service_type = $file_name[1];
	$template_fname= "template-parts/".$service_type;	
?>
<br><br><br>
		<section class="getstarted pb-2 mt-md-3">
			<div class="container">
				<div class="row mt-lg-3 px-sm-4 px-2">
					<div class="col-lg-8 landing-service pl-lg-0">
					<p class="under_line text-left my-2 pr-md-4">Reliable & Affordable Outsourcing / Powered by Technology & Talented Teams</p>
						<div class="row px-lg-3 px-0 mt-lg-0 mt-4">
						<?php
							$args = array(
							'post_parent' => 338,
							'post_type' => 'page',
							'order' => 'ASC'
							);
							$child_query = new WP_Query( $args ); ?>

							<?php while ( $child_query->have_posts() ) : $child_query->the_post();
								$currentpage_id = get_the_ID();
								$currentpage_post = get_post($currentpage_id); 
								$currentpage_slug = $currentpage_post->post_name;
								$service_page_name = explode('-', $currentpage_slug, 2);
								
								if ($service_page_name[1] == $file_name[1] ){
								?>
								<div class="col-12 it-case-study-large px-0">
								<div class="blue-header-landing py-2">
									<h3 class="text-center"><?php the_title();?></h3>
								</div>
									
								<div class="landing-service px-1">
									<?php $image2 = get_field('homepage_service_image'); ?>
									<img src="<?php echo $image2['url'];?>" class="p-0 float-left mw-sm-50 mr-sm-2"  />
									<?php $detailed = get_field('homepage_service_content');?>
									<p> <?php echo $detailed; ?></p>
								</div>
								
							</div>
							<?php get_template_part( 'template-parts/check_marks', 'none' );
							 }
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</div>
				<div class="col-lg-4 flat-box get-started-box px-0 mt-lg-0 mt-3">
					<div class="form-column pb-0 pt-xl-2 pt-3 px-xl-4 px-md-3 px-2">
						<div class="get-started-form-box landing">
							<h6 class="mb-3 under_line">REQUEST A PROPOSAL TODAY</h6>
							<?php echo do_shortcode( '[contact-form-7 id="1219" title="Get Started Form"]'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php	
		get_template_part($template_fname);
		get_template_part( 'template-parts/how_it_works', 'none' );
	
	?>
	<section class="mt-5 mb-3"  id="our_advantage">
	    	<div class="container">
	    		<div class="row pt-md-3 px-sm-0 px-2 mx-auto">
	    			<div class="col-md-8 pb-md-3 pb-0 explore_text text-center mx-auto advantage-heading">
	    		      <h3>Our Advantage</h3>
	    		    </div>
	    		</div>
			<br>
	    		<?php get_template_part( 'template-parts/our_advantage', 'none' );?>
	    	</div>
       </section>
      
      <?php
	 if($service_type != "machine-learning-ai-training" && $service_type != "content-moderation" ) { ?>
		<section class="py-5">
			<?php get_template_part( 'template-parts/software_tools', 'none' );?>
		</section>
	<?php } ?>
	
    <?php get_template_part( 'template-parts/request_consultation', 'none' ); ?>
<?php	get_footer();