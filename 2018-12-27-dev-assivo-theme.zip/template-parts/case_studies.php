 <?php
/**
 * Template part for displaying page content in page.php
 *
 *
 * @package TW_Assivo
 * @since TW_Assivo 1.0
 */

?>	
        <div class="container">
				<div class="row">
			 		<div class="col-12 explore_text pt-sm-3 mt-5 ">
			 	   		<h3>Case Studies</h3>
			    		<p>Search our library of use cases and find the right fit for your business Search our library of use cases <br> and find the right fit for your business</p>
		     		</div>
				</div>
		   		<div class="row explore_tabs text-center mt-5">
			<?php 
			$i=1;
			$taxonomy ='uc_and_cs_categories';
			$terms = get_terms( $taxonomy, array( 'order' => 'DESC') );
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					echo '<ul class="col-lg-12 nav nav-tabs p-0 d-block m-auto w-100">';
					foreach ( $terms as $term ) {
					if($i==1){?>
						<li class="nav-item d-inline-block">
							<a class="nav-link active" data-toggle="tab" href="#all_1">All Case</a>		
						</li>
						<li class="nav-item d-inline-block">
							<a class="nav-link" data-toggle="tab" href="#<?php echo $term->slug;?>_1"><?php echo $term->name;?></a>
						</li>
					<?php }
					else{
						?>
						<li class="nav-item d-inline-block">
							<a class="nav-link" data-toggle="tab" href="#<?php echo $term->slug;?>_1"><?php echo $term->name;?></a>
						</li>
					<?php
					}
						$i++;
					}
					echo '</ul>';
				}
		?>
		</div>
		<div class="row tab-content p-sm-0 px-2 home-usecase">
			<div id="all_1" class="container tab-pane active"><br>
				<div class="explore_tabs row text-center mw-100 mx-auto position-relative">
					<div class="row text-center owl-services owl-carousel owl-theme owl-nav-outer owl-dot-round mx-auto">
						<?php
							
							$args = array( 'post_type' => 'case_studies', 'posts_per_page' => -1 );
								$loop = new WP_Query( $args );
								while ( $loop->have_posts() ) : $loop->the_post();
								  ?>
									<div class="item it-case-study industry-case-study pb-3 mx-sm-1">
										<div class="bg-image ">
											<?php the_title( '<h5>', '</h5>' ); ?>
										</div>
										 <?php echo '<p>'.wp_trim_words( get_the_excerpt(),30, '...' ).'</p>';?>
											<a href="<?php echo get_permalink();?>">LEARN MORE</a>
									</div>
								  <?php
								endwhile;
							?>
					</div>
					<div id="services_nav"  class="owl-nav customNav"></div>
				</div>
				<div class="view-all mt-md-5 pb-5 pt-3">
					<a class="assivo-contact-us text-center text-white border-0 font-weight-bold" href="<?php echo esc_url( home_url( '/' ) ); ?>case-study">VIEW ALL</a>
				</div>
			</div>
			<?php 
				$terms_array = array( 
				  'taxonomy' => 'uc_and_cs_categories', 
				  'parent'   => 0 
				);
				$i=1;
				$services_terms = get_terms($terms_array); 
				foreach($services_terms as $service): ?>
				
				<div id="<?php echo $service->slug;?>_1" class="container tab-pane"><br>
					<?php 
					$post_args = array(
						  'posts_per_page' => -1,
						  'post_type' => 'case_studies', 
						  'tax_query' => array(
							  array(
								  'taxonomy' => 'uc_and_cs_categories', 
								  'field' => 'term_id', 
								  'terms' => $service->term_id,
							  )
						  )
					);
					$myposts = get_posts($post_args); ?>
					<div class="explore_tabs row text-center mw-100 mx-auto position-relative">
						<div class="row text-center owl-<?php echo $i;?> owl-carousel owl-theme owl-nav-outer owl-dot-round mx-auto">
							<?php foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
								<div class="item it-case-study industry-case-study pb-3 mx-1">
									<div class="bg-image ">
										<?php the_title( '<h5>', '</h5>' ); ?>
									</div>
									 <?php echo '<p>'.wp_trim_words( get_the_excerpt(),30, '...' ).'</p>';?>
										<a href="<?php echo get_permalink();?>">LEARN MORE</a>
								</div>
							<?php endforeach; ?>
						</div>
						<div id="<?php echo $i;?>_nav"  class="owl-nav customNav"></div>
					</div>
					<?php $i++; ?>
					<div class="view-all mt-md-5 pb-5 pt-3">
						<a class="assivo-contact-us text-center text-white border-0 font-weight-bold" href="<?php echo esc_url( home_url( '/' ) ); ?>category/<?php echo $service->slug;?>/?type=case-study">VIEW ALL</a>
					</div>
					<?php $i++; ?>
					<?php wp_reset_postdata(); ?>
				</div>
			<?php endforeach;?>  
		</div>
	</div>

	