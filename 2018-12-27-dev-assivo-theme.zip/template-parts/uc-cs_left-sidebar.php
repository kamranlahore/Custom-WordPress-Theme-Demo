 <?php
/**
 * Template part for displaying page content in page.php
 *
 *
 * @package TW_Assivo
 * @since TW_Assivo 1.0
 */


$queried_object = get_queried_object();
if(isset($_GET['type'])){
	$get_parent= $_GET['type'];	
}
else{
	$get_parent= $queried_object->post_name;
}
?>
				<div class="col-lg-3 col-md-4 col-12">
					<h2 class="bg-gradient">CATEGORIES</h2>
					<?php 
						$i=1;
						$taxonomy ='uc_and_cs_categories';
						$terms = get_terms( $taxonomy, array( 'order' => 'DESC') );
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
								echo '<ul class="case-list usecases">';
								foreach ( $terms as $term ) {
								if($i==1){?>
									<li>
									<!--<input type="checkbox" class="all-filter-check">-->
										<a href="<?php echo esc_url( home_url( '/' ) ).$get_parent;?>" class="case-filter all-cat" data-category="" data-type="category">
											<span>All Categories</span>
										</a>
									</li>
									<li>
									<input type="checkbox" class="filter-check" name="category">
									<?php	$image = get_field('icon_of_terms', $term);?>
										<a href="<?php echo get_term_link($term, $taxonomy);?>?type=<?php echo $get_parent;?>" style="background: url(<?php echo $image['url'];?>) left center no-repeat;" class="case-filter" data-<?php echo $taxonomy;?>="<?php echo $term->slug; ?>" data-type="<?php echo $taxonomy;?>">

											<span><?php echo $term->name;?></span>
										</a>
									</li>
								<?php }
								else{
									?>
									<li>
									<input type="checkbox" class="filter-check" name="category">
									<?php	$image = get_field('icon_of_terms', $term); ?>
										<a href="<?php echo get_term_link($term, $taxonomy);?>?type=<?php echo $get_parent;?>" style="background: url(<?php echo $image['url'];?>) left center no-repeat;" class="case-filter" data-<?php echo $taxonomy;?>="<?php echo $term->slug; ?>" data-type="<?php echo $taxonomy;?>">
											<span><?php echo $term->name;?></span>
										</a>
									</li>
								<?php
								}
									$i++;
								}
								echo '</ul>';
							}
					?>
					
					<h2 class="bg-gradient mt-md-3">VERTICALS</h2>
					
					<?php
						$taxonomy ='uc_and_cs_verticals';
						$terms = get_terms($taxonomy);
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
								echo '<ul class="case-list cases_vertical">';
								 ?>
								        <li>
								
								            <a href="<?php echo esc_url(home_url('/')) . $get_parent; ?>" class="case-filter all-verticals" data-vertical="" data-type="vertical">
								                <span>All Verticals</span>
								            </a>
								        </li>
								
								
							<?php								
								
								foreach ( $terms as $term ) {
								?>
									<li>
									<input type="checkbox" class="filter-check" name="verticles">
									<?php	$image = get_field('icon_of_terms', $term); ?>
										<a href="<?php echo get_term_link($term, $taxonomy);?>?type=<?php echo $get_parent;?>" style="background: url(<?php echo $image['url'];?>) left center no-repeat;" class="case-filter" data-<?php echo $taxonomy;?>="<?php echo $term->slug; ?>" data-type="<?php echo $taxonomy;?>">
											<span><?php echo $term->name;?></span>
										</a>
									</li>
								<?php
								
								}
								echo '</ul>';
							}
					?>
					
					
				</div>
				
	